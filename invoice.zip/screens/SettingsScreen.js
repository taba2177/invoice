import React, { useState, useEffect } from "react";
import { View, Text, TextInput, Button, StyleSheet, Alert } from "react-native";
import { getSettings, saveSettings } from "../utils/storage";

const SettingsScreen = ({ navigation }) => {
  const [printerIp, setPrinterIp] = useState("");
  const [printerPort, setPrinterPort] = useState("");
  const [WebViewUrl, setWebViewUrl] = useState("");


  useEffect(() => {
    // Load settings when the component mounts
    getSettings().then((settings) => {
      if (settings) {
        setWebViewUrl(settings.WebViewUrl || "");
        setPrinterIp(settings.printerIp || "");
        setPrinterPort(settings.printerPort || "9100");
      }
    });
  }, []);

  const save = async () => {
    try {
      await saveSettings({
        printerIp,
        printerPort,
        WebViewUrl,
      });
      Alert.alert("Settings saved!");
      navigation.goBack();
    } catch (error) {
      console.error("Error saving settings:", error);
      Alert.alert("Error saving settings.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>web URL:</Text>
      <TextInput
        value={WebViewUrl}
        onChangeText={setWebViewUrl}
        style={styles.input}
      />

      <Text style={styles.label}>Printer IP Address:</Text>
      <TextInput
        value={printerIp}
        onChangeText={setPrinterIp}
        style={styles.input}
      />

      <Text style={styles.label}>Printer Port:</Text>
      <TextInput
        value={printerPort}
        onChangeText={setPrinterPort}
        style={styles.input}
        keyboardType="numeric"
      />

      <Button title="Save Settings" onPress={save} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20 },
  label: { marginVertical: 10, fontWeight: "bold" },
  input: { borderColor: "#ccc", borderWidth: 1, padding: 10, marginBottom: 20 },
});

export default SettingsScreen;
