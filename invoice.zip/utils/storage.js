import AsyncStorage from "@react-native-async-storage/async-storage";

const SETTINGS_KEY = "printerSettings";

export const saveSettings = async (settings) => {
  try {
    const jsonSettings = JSON.stringify(settings);
    await AsyncStorage.setItem(SETTINGS_KEY, jsonSettings);
  } catch (e) {
    console.error("Failed to save settings", e);
  }
};

export const getSettings = async () => {
  try {
    const jsonSettings = await AsyncStorage.getItem(SETTINGS_KEY);
    return jsonSettings != null ? JSON.parse(jsonSettings) : null;
  } catch (e) {
    console.error("Failed to fetch settings", e);
  }
};
