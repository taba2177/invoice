import { generateZPL, sendToPrinter } from "../screens/printerService";
import { getSettings } from "../utils/storage";

export const handleWebViewNavigationStateChange = (
  newNavState,
  setUrl,
  handleGenerateZPL
) => {
  const { url } = newNavState;
  setUrl(url);

  // If the URL contains 'print', automatically trigger ZPL generation
  if (url.includes("print")) {
    handleGenerateZPL(url);
  }
};

export const handleGenerateZPL = async (url, webViewRef) => {
  try {
    const settings = await getSettings();
    if (!settings) {
      throw new Error("Printer settings not found");
    }

    const zplCommand = await generateZPL(url, settings);
    sendToPrinter(zplCommand, settings);
  } catch (error) {
    console.error("Error generating ZPL:", error);
    throw error;
  }
};
